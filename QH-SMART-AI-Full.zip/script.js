const CATEGORIES = [
  ["chat","🤖","AI Chat"],["image","🎨","Image"],["video","🎬","Video"],["voice","🎙️","Voice & TTS"],
  ["music","🎵","Music"],["coding","💻","Coding"],["research","🔎","Research"],["agents","🤝","AI Agents"],
  ["automation","⚙️","Automation"],["writing","✍️","Writing"],["docs","📄","PDF & Docs"],["data","📊","Data"],
  ["translation","🌐","Translation"],["education","🎓","Education"],["local","🔐","Local AI"],
  ["design","🖼️","Design"],["3d","🧊","3D"],["open","🧩","Open Source"],["search","🧭","AI Search"],["other","🧪","Other"]
];

const SEED = [
["Venice AI","https://venice.ai/","chat","freemium","Private AI chat","Private","privacy"],
["Poe","https://poe.com/","chat","freemium","Many AI models in one place","Multi-model",""],
["You.com","https://you.com/","search","freemium","AI search and research","Search","api"],
["Phind","https://www.phind.com/","coding","freemium","AI assistant for developers","Coding",""],
["Kagi Assistant","https://kagi.com/assistant","research","paid","AI assistant with search","Research",""],
["Duck.ai","https://duck.ai/","chat","free","Private AI chat","Privacy","privacy"],
["Brave Leo","https://brave.com/leo/","chat","freemium","AI assistant in Brave","Privacy",""],
["Mistral Le Chat","https://chat.mistral.ai/","chat","freemium","Mistral AI assistant","LLM",""],
["DeepSeek","https://chat.deepseek.com/","chat","free","Reasoning and coding AI","Reasoning",""],
["Grok","https://grok.com/","chat","freemium","General AI assistant","Chat",""],
["Ollama","https://ollama.com/","local","free","Run LLMs locally","Local","local"],
["LM Studio","https://lmstudio.ai/","local","free","Local LLM desktop app","Local","local"],
["Jan","https://jan.ai/","local","free","Open-source local AI","Local","local,opensource"],
["GPT4All","https://www.nomic.ai/gpt4all","local","free","Local private AI","Local","local,opensource"],
["Open WebUI","https://openwebui.com/","open","free","Self-hosted AI interface","Self-hosted","opensource,local"],
["LibreChat","https://www.librechat.ai/","open","free","Open-source multi-model chat","Self-hosted","opensource"],
["AnythingLLM","https://anythingllm.com/","docs","free","Chat with documents","RAG","opensource,local"],
["LobeHub","https://lobehub.com/","agents","free","AI workspace and agents","Agents","opensource"],
["LocalAI","https://localai.io/","local","free","OpenAI-compatible local API","API","api,local,opensource"],
["llama.cpp","https://github.com/ggml-org/llama.cpp","coding","free","Run LLMs locally","Developer","opensource,local"],
["Dify","https://dify.ai/","agents","freemium","LLM app and agent platform","Agents","api,opensource"],
["Flowise","https://flowiseai.com/","agents","free","Visual AI workflows","No-code","opensource,nocode"],
["n8n","https://n8n.io/","automation","free","Workflow automation","Automation","opensource"],
["Langflow","https://www.langflow.org/","agents","free","Visual LLM workflows","Developer","opensource,nocode"],
["Relevance AI","https://relevanceai.com/","agents","freemium","AI agents","Agents",""],
["Gumloop","https://www.gumloop.com/","automation","freemium","AI automation","Automation",""],
["Lindy","https://www.lindy.ai/","agents","freemium","AI assistants","Agents",""],
["CrewAI","https://www.crewai.com/","agents","free","Multi-agent framework","Developer","opensource"],
["AutoGen","https://microsoft.github.io/autogen/","agents","free","Multi-agent framework","Developer","opensource"],
["Perplexity","https://www.perplexity.ai/","research","freemium","AI search and research","Research",""],
["Consensus","https://consensus.app/","research","freemium","Scientific literature search","Research",""],
["Elicit","https://elicit.com/","research","freemium","Research assistant","Academic",""],
["Scite","https://scite.ai/","research","freemium","Citation analysis","Academic",""],
["NotebookLM","https://notebooklm.google.com/","docs","free","Research with your sources","Documents",""],
["Hugging Face","https://huggingface.co/","open","free","Models and AI apps","Models","opensource"],
["Leonardo AI","https://leonardo.ai/","image","freemium","AI image generation","Image",""],
["Ideogram","https://ideogram.ai/","image","freemium","Image and typography","Image",""],
["Playground","https://playground.com/","image","freemium","Image generation and editing","Image",""],
["Krea AI","https://www.krea.ai/","image","freemium","Realtime image generation","Design",""],
["Mage","https://www.mage.space/","image","freemium","Generative image platform","Image",""],
["Tensor.Art","https://tensor.art/","image","freemium","AI image models","Image",""],
["Civitai","https://civitai.com/","image","free","Community AI models","Models","opensource"],
["SeaArt AI","https://www.seaart.ai/","image","freemium","AI image creation","Image",""],
["Kling AI","https://klingai.com/","video","freemium","AI video generation","Video",""],
["Pika","https://pika.art/","video","freemium","AI video creation","Video",""],
["Luma AI","https://lumalabs.ai/","video","freemium","Generative video","Video",""],
["HeyGen","https://www.heygen.com/","video","freemium","AI avatars and video","Avatar",""],
["ElevenLabs","https://elevenlabs.io/","voice","freemium","AI voice and TTS","Voice","api"],
["Suno","https://suno.com/","music","freemium","AI music generation","Music",""]
];

const I18N = {
fa:{navTools:"ابزارهای AI",navCategories:"دسته‌بندی‌ها",navSubmit:"ثبت ابزار",heroTitle:"مرکز هوشمند ابزارهای هوش مصنوعی",heroText:"ابزارهای AI را جستجو، دسته‌بندی و مقایسه کنید؛ از چت و تصویر تا کدنویسی، صدا، تحقیق و AI محلی.",search:"جستجوی ابزار، دسته یا قابلیت...",tools:"ابزار",categories:"دسته",languages:"زبان",browse:"دسته‌بندی‌ها",allTools:"همه ابزارها",submitTitle:"ابزار AI خود را معرفی کنید",submitText:"اطلاعات ابزار هوش مصنوعی خود را برای اضافه‌شدن به دایرکتوری ارسال کنید."},
ps:{navTools:"د AI وسیلې",navCategories:"وېش",navSubmit:"وسیله ثبتول",heroTitle:"د مصنوعي ځیرکتیا د وسایلو مرکز",heroText:"د AI وسایل ولټوئ، طبقه‌بندي او پرتله کړئ.",search:"د وسیلې، وېش یا ځانګړتیا لټون...",tools:"وسایل",categories:"وېشونه",languages:"ژبې",browse:"وېشونه",allTools:"ټول وسایل",submitTitle:"خپل AI وسیله معرفي کړئ",submitText:"د خپلې AI وسیلې معلومات واستوئ."},
en:{navTools:"AI Tools",navCategories:"Categories",navSubmit:"Submit Tool",heroTitle:"Smart AI Tools Directory",heroText:"Discover, search and compare AI tools for chat, image, video, coding, voice, research and local AI.",search:"Search tools, categories or features...",tools:"Tools",categories:"Categories",languages:"Languages",browse:"Categories",allTools:"All Tools",submitTitle:"Submit an AI tool",submitText:"Send your AI tool information for inclusion in the directory."}
};

let tools = JSON.parse(localStorage.getItem("qhSmartTools") || "null") || SEED.map((x,i)=>({id:i+1,name:x[0],url:x[1],cat:x[2],price:x[3],desc:x[4],tag:x[5],features:x[6]}));
let lang="fa", currentCat="all";

const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const catName=id=>(CATEGORIES.find(c=>c[0]===id)||["","","Other"])[2];
function save(){localStorage.setItem("qhSmartTools",JSON.stringify(tools));}
function initials(n){return n.split(/\s+/).slice(0,2).map(x=>x[0]).join("").toUpperCase();}
function priceLabel(p){return p==="free"?"رایگان":p==="paid"?"پولی":"Freemium";}

function renderCategories(){
  $("#categoryGrid").innerHTML=CATEGORIES.map(c=>`<button class="category" data-cat="${c[0]}"><span class="cat-icon">${c[1]}</span><span>${c[2]}</span></button>`).join("");
  $("#categoryFilter").innerHTML=`<option value="all">همه دسته‌ها</option>`+CATEGORIES.map(c=>`<option value="${c[0]}">${c[1]} ${c[2]}</option>`).join("");
  $("#newCat").innerHTML=CATEGORIES.map(c=>`<option value="${c[0]}">${c[2]}</option>`).join("");
  $$(".category").forEach(b=>b.onclick=()=>{currentCat=b.dataset.cat;$("#categoryFilter").value=currentCat;renderTools();$("#tools").scrollIntoView({behavior:"smooth"})});
}
function renderChips(){
  const chips=[["all","همه"],["free","رایگان"],["chat","چت"],["image","تصویر"],["coding","کدنویسی"],["research","تحقیق"],["local","Local AI"],["open","Open Source"]];
  $("#chips").innerHTML=chips.map(x=>`<button class="chip ${currentCat===x[0]?"active":""}" data-chip="${x[0]}">${x[1]}</button>`).join("");
  $$(".chip").forEach(b=>b.onclick=()=>{currentCat=b.dataset.chip;$("#categoryFilter").value=["free"].includes(currentCat)?"all":currentCat;renderTools()});
}
function filtered(){
  const q=$("#search").value.trim().toLowerCase(), price=$("#priceFilter").value, feat=$("#featureFilter").value, sort=$("#sortFilter").value;
  let a=tools.filter(t=>{
    const text=(t.name+" "+t.desc+" "+t.tag+" "+catName(t.cat)).toLowerCase();
    return (!q||text.includes(q))&&(currentCat==="all"||t.cat===currentCat||t.price===currentCat||t.features.includes(currentCat))&&(price==="all"||t.price===price)&&(feat==="all"||t.features.includes(feat));
  });
  if(sort==="name")a.sort((x,y)=>x.name.localeCompare(y.name));
  if(sort==="free")a.sort((x,y)=>(x.price==="free"?0:1)-(y.price==="free"?0:1));
  if(sort==="new")a.sort((x,y)=>y.id-x.id);
  return a;
}
function renderTools(){
  const a=filtered();$("#resultCount").textContent=`${a.length} نتیجه`;$("#countStat").textContent=tools.length;
  $("#empty").classList.toggle("hidden",a.length>0);
  $("#toolsGrid").innerHTML=a.map(t=>`<article class="tool">
    <div class="tool-top"><div class="tool-logo">${initials(t.name)}</div><span class="badge">${priceLabel(t.price)}</span></div>
    <h3>${t.name}</h3><p>${t.desc}</p>
    <div class="tags"><span class="tag">${catName(t.cat)}</span><span class="tag">${t.tag}</span>${t.features.split(",").filter(Boolean).map(f=>`<span class="tag">${f}</span>`).join("")}</div>
    <div class="tool-actions"><a class="open-btn" href="${t.url}" target="_blank" rel="noopener noreferrer">Open ↗</a><button class="details-btn" onclick="showDetails(${t.id})">جزئیات</button></div>
  </article>`).join("");
  renderChips();
}
window.showDetails=id=>{
  const t=tools.find(x=>x.id===id);if(!t)return;
  $("#modalBody").innerHTML=`<div class="tool-logo">${initials(t.name)}</div><h2>${t.name}</h2><p>${t.desc}</p><p><b>دسته:</b> ${catName(t.cat)}<br><b>قیمت:</b> ${priceLabel(t.price)}<br><b>قابلیت‌ها:</b> ${t.features||"—"}</p><a class="open-btn" style="display:block" href="${t.url}" target="_blank" rel="noopener noreferrer">بازکردن سایت ↗</a>`;
  $("#toolModal").classList.remove("hidden");
};
function setLang(l){
  lang=l;const d=I18N[l];document.documentElement.lang=l;document.documentElement.dir=l==="en"?"ltr":"rtl";
  $$("[data-i18n]").forEach(e=>e.textContent=d[e.dataset.i18n]||e.textContent);
  $$("[data-i18n-placeholder]").forEach(e=>e.placeholder=d[e.dataset.i18nPlaceholder]||e.placeholder);
  $("#langBtn").textContent=l==="fa"?"EN":l==="en"?"پښتو":"دری";
}
$("#search").addEventListener("input",renderTools);
["categoryFilter","priceFilter","featureFilter","sortFilter"].forEach(id=>$("#"+id).addEventListener("change",e=>{if(id==="categoryFilter")currentCat=e.target.value;renderTools()}));
$("#resetBtn").onclick=()=>{$("#search").value="";currentCat="all";$("#categoryFilter").value="all";$("#priceFilter").value="all";$("#featureFilter").value="all";$("#sortFilter").value="featured";renderTools()};
$("#themeBtn").onclick=()=>document.body.classList.toggle("light");
$("#langBtn").onclick=()=>setLang(lang==="fa"?"en":lang==="en"?"ps":"fa");
$("#adminBtn").onclick=()=>{$("#adminModal").classList.remove("hidden");$("#adminTotal").textContent=tools.length;$("#adminFree").textContent=tools.filter(x=>x.price!=="paid").length;$("#adminCats").textContent=new Set(tools.map(x=>x.cat)).size};
$("#submitBtn").onclick=()=>$("#submitModal").classList.remove("hidden");
$$("[data-close]").forEach(b=>b.onclick=()=>$("#"+b.dataset.close).classList.add("hidden"));
window.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){e.preventDefault();$("#search").focus()}if(e.key==="Escape")$$(".modal").forEach(m=>m.classList.add("hidden"))});
$("#addTool").onclick=()=>{
  const name=$("#newName").value.trim(),url=$("#newUrl").value.trim(),desc=$("#newDesc").value.trim(),cat=$("#newCat").value,price=$("#newPrice").value;
  if(!name||!url)return alert("نام و لینک الزامی است.");
  tools.unshift({id:Date.now(),name,url,cat,price,desc:desc||"ابزار هوش مصنوعی",tag:"New",features:""});
  save();renderTools();$("#newName").value=$("#newUrl").value=$("#newDesc").value="";
  $("#adminTotal").textContent=tools.length;$("#adminFree").textContent=tools.filter(x=>x.price!=="paid").length;
};
$("#year").textContent=new Date().getFullYear();
renderCategories();renderTools();setLang("fa");
